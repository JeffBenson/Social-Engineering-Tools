﻿using Microsoft.EntityFrameworkCore;
using DoxxInterface.Models;

namespace DoxxInterface.Data
{
    public class MvcDoxxContext : DbContext
    {
        public MvcDoxxContext(DbContextOptions<MvcDoxxContext> options)
            : base(options)
        {
        }

        public DbSet<DoxxModel> Doxx { get; set; }
    }
}