﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using DoxxInterface.Data;
using DoxxInterface.Models;

namespace DoxxInterface.Controllers
{
    public class DoxxModelsController : Controller
    {
        private readonly MvcDoxxContext _context;

        public DoxxModelsController(MvcDoxxContext context)
        {
            _context = context;
        }

        // GET: DoxxModels
        public async Task<IActionResult> Index()
        {
            return View(await _context.Doxx.ToListAsync());
        }

        // GET: DoxxModels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var doxxModel = await _context.Doxx
                .FirstOrDefaultAsync(m => m.Id == id);
            if (doxxModel == null)
            {
                return NotFound();
            }

            return View(doxxModel);
        }

        // GET: DoxxModels/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: DoxxModels/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,LastName,FirstName,MiddleName,Age,DOB,Gender,Occupation,CurrentPhone,AltPhone,AltPhone2,Email,AltEmail,AltEmail2,Address,Address2,Address3,LinkedIn,Facebook,Twitter")] DoxxModel doxxModel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(doxxModel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(doxxModel);
        }

        // GET: DoxxModels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var doxxModel = await _context.Doxx.FindAsync(id);
            if (doxxModel == null)
            {
                return NotFound();
            }
            return View(doxxModel);
        }

        // POST: DoxxModels/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,LastName,FirstName,MiddleName,Age,DOB,Gender,Occupation,CurrentPhone,AltPhone,AltPhone2,Email,AltEmail,AltEmail2,Address,Address2,Address3,LinkedIn,Facebook,Twitter")] DoxxModel doxxModel)
        {
            if (id != doxxModel.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(doxxModel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DoxxModelExists(doxxModel.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(doxxModel);
        }

        // GET: DoxxModels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var doxxModel = await _context.Doxx
                .FirstOrDefaultAsync(m => m.Id == id);
            if (doxxModel == null)
            {
                return NotFound();
            }

            return View(doxxModel);
        }

        // POST: DoxxModels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var doxxModel = await _context.Doxx.FindAsync(id);
            _context.Doxx.Remove(doxxModel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DoxxModelExists(int id)
        {
            return _context.Doxx.Any(e => e.Id == id);
        }
    }
}
