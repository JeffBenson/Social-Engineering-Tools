﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace DoxxInterface.Models
{
    public class DoxxModel
    {
        public int Id { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public int Age { get; set; }
        [DataType(DataType.Date)]
        public string DOB { get; set; }
        public string Gender { get; set; }
        public string Occupation { get; set; }
        public string CurrentPhone { get; set; }
        public string AltPhone { get; set; }
        public string AltPhone2 { get; set; }
        public string Email { get; set; }
        public string AltEmail { get; set; }
        public string AltEmail2 { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string LinkedIn { get; set; }
        public string Facebook { get; set; }
        public string Twitter { get; set; }

    }
}
